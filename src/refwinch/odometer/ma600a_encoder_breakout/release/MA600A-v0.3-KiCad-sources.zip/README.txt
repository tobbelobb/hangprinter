MA600A v0.3, 2026-09-09. Open kicad/MA600A-RefWinch-Encoder.kicad_pro.
KiCad 10.0.6 checked sources and self-contained libraries. See the accompanying order instructions and design review for prototype limits and manufacturing settings.
